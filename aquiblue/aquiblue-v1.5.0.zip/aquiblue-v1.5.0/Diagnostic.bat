@echo off
title Diagnostic AquiBlue
echo === Diagnostic AquiBlue === > "%TEMP%\diagnostic-banc.txt"
echo Date : %date% %time% >> "%TEMP%\diagnostic-banc.txt"
echo. >> "%TEMP%\diagnostic-banc.txt"

echo [1/4] Python...
where python >> "%TEMP%\diagnostic-banc.txt" 2>&1
python --version >> "%TEMP%\diagnostic-banc.txt" 2>&1

echo [2/4] Module bleak...
python -c "import bleak; print('bleak', bleak.__version__)" >> "%TEMP%\diagnostic-banc.txt" 2>&1

echo [3/4] Adaptateur Bluetooth...
powershell -NoProfile -Command "Get-PnpDevice -Class Bluetooth -Status OK | Select-Object -ExpandProperty FriendlyName" >> "%TEMP%\diagnostic-banc.txt" 2>&1

echo [4/4] Port 2015 libre ?
netstat -an | findstr ":2015" >> "%TEMP%\diagnostic-banc.txt" 2>&1

echo. >> "%TEMP%\diagnostic-banc.txt"
echo Rapport ecrit. Il s'ouvre dans le Bloc-notes :
notepad "%TEMP%\diagnostic-banc.txt"
