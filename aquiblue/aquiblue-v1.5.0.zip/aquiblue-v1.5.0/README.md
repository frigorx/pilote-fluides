# inerWeb AquiBlue — Acquisition de données Bluetooth

Banc de mesure pédagogique : des sondes Bluetooth du commerce (température,
pression, air) tracent le **cycle frigorifique en direct** sur un diagramme
enthalpique. Pensé pour les ateliers froid et climatisation (CAP, Bac Pro,
BTS), du premier branchement au diagnostic de panne.

Outil indépendant, non affilié à un fabricant d'instruments.

**Logiciel libre et gratuit — licence GPL-3.0** (voir `LICENSE`).
La séquence d'initialisation des sondes dérive du projet
[`testo405i_mqtt`](https://github.com/VladimirHulagov) de Vladimir Hulagov
(GPL-3.0) : ce projet entier est distribué sous la même licence, comme elle
l'exige. Merci à lui.

## Lancer

**Sans rien installer (simulation)** : double-cliquer `web/index.html`.
La page est autonome — tables thermodynamiques embarquées, simulation
intégrée, aucun réseau. Bandeau orange permanent : les valeurs sont simulées.

**Avec les vraies sondes** :

```bash
pip install bleak
python serveur.py
```

Le navigateur s'ouvre sur `http://127.0.0.1:2015/` (poste élève : le pupitre
d'injection de défauts est masqué ; poste professeur : `?prof=1`).
Une sonde allumée apparaît toute seule → « Ajouter au banc » → taper son
numéro de série en face du point de mesure → le cycle se dessine.
Prérequis : Windows 10 (1709+) ou 11, Bluetooth 4.0+ (dongle USB conseillé),
Python 3.12+.

## Ce que fait le banc

- Diagramme de Mollier animé, 4 fluides (R-134a, R-404A, R-449A, R-290) ;
  surchauffe et surchauffe totale (sur la rosée), sous-refroidissement et
  total (sur la bulle), taux de compression, ΔT air.
- Modes SIMULATION / RÉEL jamais mélangés : chaque valeur porte sa
  provenance et sa fraîcheur ; une mesure périmée n'alimente pas le cycle.
- 5 défauts injectables côté professeur, l'élève diagnostique à l'aveugle.
- Enregistrement, rejeu accéléré (×5 à ×60), export CSV, relevé PDF.
- Saisie manuelle (pression relative/absolue ou température de saturation)
  quand un appareil manque — les manomètres fixes de l'atelier suffisent.
- Tare des manomètres persistée, journaux de capture bornés et effaçables,
  tout fonctionne **hors ligne** : aucune donnée ne quitte le poste.

## Pour les enseignants

Les plans de séance, la feuille de guidance élève et la fiche de relevé
(hybride numérique + papier) sont diffusés à part, sur demande par e-mail :
**inerweb.fh@gmail.com**, objet « AquiBlue — demande de code ».

## Architecture

```
serveur.py               pont HTTP local durci (127.0.0.1, actions en POST)
acquisition/
  base.py                contrat commun SourceAcquisition
  simulateur.py          source simulée (repli sans matériel)
  protocole_reel.py      décodage des sondes (handshake + trames)
  source_reelle.py       vue temps réel conforme au contrat
web/index.html           interface complète, autonome
web/fluides.json         tables thermodynamiques (CoolProp 8.0.0, IIR)
outils/                  génération des tables, construction du paquet
tests/                   28 tests (décodage, exactitude ≤ 7 mK, sécurité)
```

Règle d'architecture : **un module d'acquisition par famille de capteurs**,
tous derrière la même interface — les familles futures (filaire 4-20 mA,
autres sondes BLE) s'ajoutent sans toucher au reste.

## Licence

GPL-3.0 (`LICENSE`). Vous pouvez utiliser, étudier, modifier et redistribuer
ce logiciel, y compris vos versions modifiées, aux conditions de la GPL :
mêmes libertés pour les destinataires, sources incluses, mentions conservées.
Fourni sans garantie ; les valeurs affichées dépendent des sondes et de leur
pose — cet outil pédagogique ne remplace aucun instrument réglementaire.
