@echo off
title inerWeb AquiBlue - poste professeur
cd /d "%~dp0moteur"
where python >nul 2>nul
if errorlevel 1 (
  echo Python est absent : voir "Lancer AquiBlue.bat" pour les solutions.
  pause
  exit /b 1
)
start "" http://127.0.0.1:2015/?prof=1
python serveur.py --sans-navigateur
