@echo off
title Desinstallation d'AquiBlue
echo Ce script efface les DONNEES LOCALES d'AquiBlue sur ce poste :
echo   %LOCALAPPDATA%\banc-acquisition-ble
echo (journaux de capture, etalonnage, journal technique)
echo.
set /p REP="Confirmer l'effacement ? (O/N) "
if /i not "%REP%"=="O" goto abandon
rmdir /s /q "%LOCALAPPDATA%\banc-acquisition-ble" 2>nul
echo Donnees locales effacees.
echo Pour finir la desinstallation : supprimer ce dossier du programme.
pause
exit /b 0
:abandon
echo Abandon, rien n'a ete efface.
pause
