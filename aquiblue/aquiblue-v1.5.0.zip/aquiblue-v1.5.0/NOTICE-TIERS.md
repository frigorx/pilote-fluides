# NOTICE DES COMPOSANTS TIERS — Banc d'acquisition BLE

Établie le 22/08/2026 (Lot 1). Recense tout élément non écrit spécifiquement
pour ce projet. Complément machine : `SBOM.json` (CycloneDX).

## Composants logiciels tiers utilisés à l'exécution

| Composant | Version | Licence | Rôle | Distribution |
|---|---|---|---|---|
| Python | 3.14.0 | PSF License | Interpréteur du serveur local | Non distribué (prérequis poste) |
| bleak | 3.0.2 | MIT | Accès Bluetooth Low Energy sous Windows | Non distribué (installé par pip) |

## Composants tiers utilisés seulement en développement

| Composant | Version | Licence | Rôle |
|---|---|---|---|
| CoolProp | 8.0.0 | MIT | Génération des tables thermodynamiques (`outils/generer_tables.py`) |

Les tables `web/fluides.json` (et leur copie embarquée dans `web/index.html`)
sont des **données dérivées de CoolProp** (convention IIR). La licence MIT de
CoolProp autorise cette dérivation ; l'attribution est due et faite ici.

## Dérivation GPL assumée ✅ (résolue le 23/08/2026)

| Élément | Origine | Licence | Statut |
|---|---|---|---|
| Séquence d'initialisation BLE des sondes (handshake sur `fff1`) | Projet `testo405i_mqtt` de Vladimir Hulagov | **GPL-3.0** | **INTÉGRÉE — le projet entier est distribué sous GPL-3.0** |

La connaissance de la séquence d'initialisation provient de ce projet GPL.
Décision du 23/08/2026 : plutôt que de lever la dérivation (capture ou avis
juridique), **AquiBlue adopte la GPL-3.0 et se distribue gratuitement** —
l'hérédité de la licence est ainsi respectée, l'attribution est portée ici
et dans le `README.md`. Merci à Vladimir Hulagov.

## Ce que le projet n'embarque pas

- Aucune bibliothèque JavaScript tierce : `web/index.html` est autonome,
  écrit pour le projet (vérifié par recherche de motifs licence/copyright).
- Aucun code, écran, logo, texte ou fichier du fabricant des sondes.
- Aucun composant réseau distant : pas de CDN, pas de télémétrie, pas de cloud.

## Travaux d'IA à créditer

- Le **dossier de mise en conformité** (`dossier-conformite/`) est le travail
  d'une autre IA que celle qui a écrit le code ; il est intégré tel quel.
- Le code applicatif a été écrit par l'outil d'IA Claude Code sous la
  direction et la vérification de F. Henninot
  (détail : `PROVENANCE-CODE-ET-ASSETS.md`).
