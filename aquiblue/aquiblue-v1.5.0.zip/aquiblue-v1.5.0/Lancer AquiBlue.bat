@echo off
title inerWeb AquiBlue - Acquisition de donnees Bluetooth
cd /d "%~dp0moteur"
where python >nul 2>nul
if errorlevel 1 goto sanspython
python serveur.py
goto fin
:sanspython
echo.
echo   Python est absent de ce poste.
echo   Deux solutions :
echo     1. Installer Python depuis python.org (cocher "Add to PATH"),
echo        puis :  pip install -r requirements.txt
echo     2. Sans Python : ouvrir moteur\web\index.html (double-clic)
echo        pour la version DEMONSTRATION (sondes simulees uniquement).
echo.
pause
:fin
