# inerWeb AquiBlue — GPL-3.0 (voir LICENSE).
"""
Interface commune à toutes les sources d'acquisition.

Règle d'architecture du projet : un module par famille de capteurs, tous
exposant cette même interface. Ajouter une famille (sondes BLE, manifold
quatre voies, pince ampèremétrique) ne doit rien changer aux couches
supérieures — serveur, calculs, diagramme.

C'est le rôle que tenait `modbus_engine.py` dans le projet AK-CC 550.
"""

from dataclasses import dataclass, field
from typing import Protocol


# États possibles d'une sonde, affichés tels quels à l'élève.
CONNECTEE = "connectee"
PERDUE = "perdue"
FIGEE = "figee"       # connectée, mais la valeur ne bouge plus depuis trop longtemps

# Origine d'une mesure — jamais mélangée en silence (exigence du dossier de
# conformité, lot 3). Chaque valeur porte la sienne.
SIMULATION = "simulation"
REEL = "reel"
REJEU = "rejeu"
MANUEL = "manuel"


@dataclass
class Mesure:
    """Une mesure, avec sa provenance et sa fraîcheur.

    Aucune notion de « point de mesure » ici : la sonde ne sait pas où elle
    est posée. C'est l'élève qui fait le lien, et c'est tout l'objet du TP.

    `source` dit d'où vient la valeur (simulation / réel / rejeu / manuel) :
    la couche haute ne doit JAMAIS afficher une valeur simulée comme réelle.
    """

    serie: str                    # numéro de série lu sur la sonde physique
    modele: str                   # « Manomètre BLE », « Pince T° BLE »…
    grandeur: str                 # « pression », « temperature », « vitesse »…
    valeur: float | None          # None si la sonde ne répond plus
    unite: str                    # « bar » (relatif) ou « °C »
    etat: str = CONNECTEE
    source: str = SIMULATION      # SIMULATION / REEL / REJEU / MANUEL
    batterie: int | None = None   # pourcentage, None si inconnu
    horodatage: float = 0.0       # time.time() de la dernière trame reçue
    age_ms: int = 0               # âge de la mesure au moment de la lecture
    rssi: int | None = None


@dataclass
class EtatSource:
    """Ce que la couche haute a besoin de savoir sur la source."""

    nom: str
    active: bool = False
    detail: str = ""
    sondes_attendues: int = 0
    sondes_connectees: int = 0
    avertissements: list[str] = field(default_factory=list)


class SourceAcquisition(Protocol):
    """Contrat que chaque module d'acquisition doit remplir.

    Un échec sur une famille de capteurs ne doit jamais dégrader les autres :
    chaque implémentation gère ses propres reconnexions et signale ses sondes
    perdues par l'état de la mesure, sans lever d'exception vers le serveur.
    """

    def demarrer(self) -> None:
        """Ouvre la source et lance l'acquisition en tâche de fond."""
        ...

    def arreter(self) -> None:
        """Ferme proprement, sans lever d'exception."""
        ...

    def lire(self) -> list[Mesure]:
        """Dernières mesures connues, une par sonde. Jamais bloquant."""
        ...

    def etat(self) -> EtatSource:
        """État de la source, pour l'affichage et le diagnostic."""
        ...
