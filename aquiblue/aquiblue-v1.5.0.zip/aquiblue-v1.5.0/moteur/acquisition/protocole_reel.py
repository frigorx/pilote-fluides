# inerWeb AquiBlue — GPL-3.0 (voir LICENSE). Ce module est celui qui dérive
# de testo405i_mqtt (Vladimir Hulagov, GPL-3.0) : la séquence d'initialisation
# en provient ; le décodage des trames vient de nos captures in situ.
"""
Protocole réel des sondes d'acquisition Bluetooth — percé in situ le 22/08/2026.

Décodage établi par corrélation directe sur le matériel (pince à 38 °C en
refroidissement, anémomètre à 0 m/s), avec l'appui du projet open source
« testo405i_mqtt » de VladimirHulagov (GitHub) pour la séquence d'init.

Marche à suivre :
1. s'abonner aux notifications de la caractéristique FFF2 ;
2. envoyer la séquence INIT sur FFF1 (sinon la sonde ne renvoie qu'un accusé) ;
3. réassembler les fragments et lire, après chaque étiquette texte
   (« LineTemperature », « Temperature », « Velocity », « Pressure »,
   « Humidity », « BatteryLevel »…), un float32 little-endian.

Le protocole est commun à toute la gamme : une seule implémentation couvre
pinces de température, thermomètres, anémomètre. Le manomètre (pression)
suit le même schéma avec l'étiquette « Pressure » (à confirmer sur un 549i).
"""

import struct

UUID_ECRITURE = "0000fff1-0000-1000-8000-00805f9b34fb"
UUID_NOTIFY = "0000fff2-0000-1000-8000-00805f9b34fb"

# Séquence d'initialisation à écrire sur FFF1 pour déclencher le flux de mesures.
SEQUENCE_INIT = [
    "5600030000000c69023e81",
    "200000000000077b",
    "04001500000005930f0000004669726d77617265",
    "56657273696f6e304f",
    "04001500000005930f0000004669726d77617265",
    "56657273696f6e304f",
    "04001600000005d7100000004d6561737572656d",
    "656e744379636c656161",
    "110000000000035a",
]

# Étiquettes rencontrées dans les trames → (grandeur, unité, facteur d'échelle).
# Le facteur convertit l'unité brute de la sonde vers celle du banc :
# le manomètre 549i envoie une pression DIFFÉRENTIELLE (relative) en pascals,
# convertie en bar (×1e-5). Le réassemblage prend l'étiquette la plus précoce
# dans le tampon, ce qui gère « DifferentialPressure » avant son sous-mot
# « Pressure » et « LineTemperature » avant « Temperature ».
ETIQUETTES = [
    (b"DifferentialPressure", "pression", "bar", 1e-5),
    (b"LineTemperature", "temperature", "°C", 1.0),
    (b"Temperature", "temperature", "°C", 1.0),
    (b"Pressure", "pression", "bar", 1e-5),
    (b"Velocity", "vitesse", "m/s", 1.0),
    (b"Humidity", "humidite", "%HR", 1.0),
    (b"BatteryLevel", "batterie", "%", 1.0),
]


class LecteurTrames:
    """Réassemble les fragments d'une sonde et en extrait les mesures.

    Une instance par sonde connectée. `alimenter(data)` avale un fragment BLE
    et renvoie la liste des (grandeur, valeur, unite) nouvellement décodés.
    """

    def __init__(self):
        self._tampon = bytearray()

    def alimenter(self, data: bytes):
        self._tampon.extend(data)
        trouves = []
        # On boucle tant qu'on sait décoder une étiquette complète en tête utile.
        while True:
            # Cherche l'étiquette la plus précoce dans le tampon.
            meilleure = None
            for mot, grandeur, unite, echelle in ETIQUETTES:
                i = self._tampon.find(mot)
                if i != -1 and (meilleure is None or i < meilleure[0]):
                    meilleure = (i, mot, grandeur, unite, echelle)
            if meilleure is None:
                # Aucun mot : on évite que le tampon enfle sans fin.
                if len(self._tampon) > 256:
                    del self._tampon[:-32]
                return trouves

            i, mot, grandeur, unite, echelle = meilleure
            fin_mot = i + len(mot)
            if len(self._tampon) < fin_mot + 4:
                # Le float n'est pas encore arrivé : on attend le prochain fragment.
                return trouves

            valeur = struct.unpack_from("<f", self._tampon, fin_mot)[0] * echelle
            # On consomme jusqu'après le float (4 octets) : le reste peut contenir
            # d'autres étiquettes.
            del self._tampon[: fin_mot + 4]

            if _plausible(grandeur, valeur):
                trouves.append((grandeur, round(valeur, 3), unite))


def _plausible(grandeur, valeur):
    """Garde-fou : rejette les valeurs aberrantes (fragment mal aligné)."""
    if valeur != valeur or abs(valeur) > 1e6:   # NaN / démesuré
        return False
    if grandeur == "temperature":
        return -80 < valeur < 200
    if grandeur == "pression":
        return -2 < valeur < 60
    if grandeur == "vitesse":
        return -1 < valeur < 60
    if grandeur == "humidite":
        return 0 <= valeur <= 100
    if grandeur == "batterie":
        return 0 <= valeur <= 100
    return True
