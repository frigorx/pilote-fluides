# inerWeb AquiBlue — GPL-3.0 (voir LICENSE).
"""
Source d'acquisition simulée — repli sans matériel, et matière des exercices.

Reproduit le parc réel (2 manomètres BLE, 5 pinces de température BLE,
2 thermomètres d'air BLE) et son comportement : numéros de série, batterie,
sondes qui décrochent.

Point important : comme les vraies sondes, chaque sonde simulée ignore où
elle est posée. Elle renvoie la valeur de son emplacement physique, sans
jamais le nommer. C'est l'élève qui fait le lien entre le numéro de série
qu'il lit sur le boîtier et le point de mesure — et c'est là qu'il peut se
tromper, ce que le diagramme révèlera tout seul.

Les manomètres renvoient une pression RELATIVE, comme les appareils réels.
"""

import json
import math
import random
import threading
import time
from pathlib import Path

from .base import CONNECTEE, PERDUE, EtatSource, Mesure

FICHIER_FLUIDES = Path(__file__).resolve().parent.parent / "web" / "fluides.json"
PRESSION_ATMO = 1.013


# Parc simulé : (série, modèle, grandeur, emplacement physique réel).
# L'emplacement n'est jamais transmis à l'interface — il sert seulement à
# fabriquer une valeur cohérente.
PARC = [
    ("31207744", "Manomètre BLE", "pression", "hp"),
    ("31207891", "Manomètre BLE", "pression", "bp"),
    ("42118056", "Pince T° BLE", "temperature", "sortie_condenseur"),
    ("42118093", "Pince T° BLE", "temperature", "entree_detendeur"),
    ("42118117", "Pince T° BLE", "temperature", "sortie_evaporateur"),
    ("42118342", "Pince T° BLE", "temperature", "entree_compresseur"),
    ("42117905", "Pince T° BLE", "temperature", "ambiance_froid"),
    ("50034271", "Thermomètre air BLE", "temperature", "air_reprise_condenseur"),
    ("50034288", "Thermomètre air BLE", "temperature", "air_souffle_condenseur"),
]

# Point de fonctionnement nominal d'une chambre froide positive.
NOMINAL = {
    "t_evaporation": -8.0,      # température de rosée à la BP
    "t_condensation": 40.0,     # température de bulle à la HP
    "surchauffe": 6.0,
    "sous_refroidissement": 5.0,
    "rechauffement_aspiration": 2.0,   # entre sortie évaporateur et compresseur
    "refroidissement_liquide": 1.0,    # entre sortie condenseur et détendeur
    "air_reprise_condenseur": 25.0,
    "ecart_air_condenseur": 8.0,
    "ambiance_froid": 4.0,
}

# Défauts injectables : décalages appliqués au point de fonctionnement.
# Ce sont les perturbations du TP 3 et les pannes à diagnostiquer du TP 4.
DEFAUTS = {
    "condenseur_encrasse": {
        "libelle": "Condenseur encrassé",
        "indice": "La HP grimpe, l'air ressort plus chaud du condenseur.",
        "effets": {"t_condensation": +13.0, "sous_refroidissement": -2.0,
                   "ecart_air_condenseur": +5.0},
    },
    "detendeur_ferme": {
        "libelle": "Détendeur trop fermé",
        "indice": "La BP s'effondre et la surchauffe part très haut.",
        "effets": {"t_evaporation": -11.0, "surchauffe": +16.0,
                   "sous_refroidissement": +3.0, "ambiance_froid": +4.0},
    },
    "manque_charge": {
        "libelle": "Manque de fluide",
        "indice": "BP basse, surchauffe forte, plus de sous-refroidissement.",
        "effets": {"t_evaporation": -8.0, "surchauffe": +12.0,
                   "sous_refroidissement": -4.8, "t_condensation": -4.0,
                   "ambiance_froid": +3.0},
    },
    "surcharge": {
        "libelle": "Surcharge en fluide",
        "indice": "HP haute et sous-refroidissement anormalement grand.",
        "effets": {"t_condensation": +9.0, "sous_refroidissement": +9.0,
                   "surchauffe": -2.0},
    },
    "evaporateur_givre": {
        "libelle": "Évaporateur givré",
        "indice": "BP qui descend lentement, la chambre ne tient plus.",
        "effets": {"t_evaporation": -7.0, "surchauffe": +4.0,
                   "ambiance_froid": +5.0},
    },
}


def _charger_tables():
    return json.loads(FICHIER_FLUIDES.read_text(encoding="utf-8"))


def _pression_pour_temperature(sat, t_cible, colonne):
    """Pression de saturation (bar absolus) pour une température donnée.

    `colonne` vaut « tr » (rosée, côté BP) ou « tb » (bulle, côté HP) : sur un
    fluide à glissement, ce n'est pas la même chose.
    """
    for a, b in zip(sat, sat[1:]):
        if a[colonne] <= t_cible <= b[colonne]:
            f = (t_cible - a[colonne]) / (b[colonne] - a[colonne])
            return a["p"] + f * (b["p"] - a["p"])
    return sat[0]["p"] if t_cible < sat[0][colonne] else sat[-1]["p"]


class SimulateurBanc:
    """Source d'acquisition simulée, conforme à l'interface SourceAcquisition."""

    def __init__(self, fluide: str = "R449A"):
        self.fluide = fluide
        self._tables = _charger_tables()
        self._defauts_actifs: set[str] = set()
        self._sondes_coupees: set[str] = set()
        self._mesures: dict[str, Mesure] = {}
        self._verrou = threading.Lock()
        self._tourne = False
        self._fil: threading.Thread | None = None
        self._t0 = time.time()
        self._batteries = {s[0]: random.randint(62, 99) for s in PARC}

    # ─────────────────── Interface SourceAcquisition ───────────────────

    def demarrer(self) -> None:
        if self._tourne:
            return
        self._tourne = True
        self._fil = threading.Thread(target=self._boucle, daemon=True)
        self._fil.start()

    def arreter(self) -> None:
        self._tourne = False

    def lire(self) -> list[Mesure]:
        with self._verrou:
            return list(self._mesures.values())

    def etat(self) -> EtatSource:
        with self._verrou:
            connectees = sum(1 for m in self._mesures.values() if m.etat == CONNECTEE)
        avertissements = []
        if self._defauts_actifs:
            libelles = [DEFAUTS[d]["libelle"] for d in self._defauts_actifs]
            avertissements.append("Défaut simulé : " + ", ".join(libelles))
        return EtatSource(
            nom="Simulateur de banc (aucun matériel connecté)",
            active=self._tourne,
            detail=f"Fluide {self._tables[self.fluide]['nom']}",
            sondes_attendues=len(PARC),
            sondes_connectees=connectees,
            avertissements=avertissements,
        )

    # ─────────────────── Pilotage du démonstrateur ───────────────────

    def basculer_defaut(self, cle: str) -> bool:
        """Active ou désactive un défaut. Retourne son nouvel état."""
        if cle not in DEFAUTS:
            raise KeyError(cle)
        if cle in self._defauts_actifs:
            self._defauts_actifs.discard(cle)
            return False
        self._defauts_actifs.add(cle)
        return True

    def basculer_sonde(self, serie: str) -> bool:
        """Coupe ou rétablit une sonde, pour montrer la perte de liaison."""
        if serie in self._sondes_coupees:
            self._sondes_coupees.discard(serie)
            return True
        self._sondes_coupees.add(serie)
        return False

    def remettre_a_zero(self) -> None:
        self._defauts_actifs.clear()
        self._sondes_coupees.clear()

    def defauts(self) -> list[dict]:
        return [
            {"cle": c, "libelle": d["libelle"], "indice": d["indice"],
             "actif": c in self._defauts_actifs}
            for c, d in DEFAUTS.items()
        ]

    def changer_fluide(self, cle: str) -> None:
        if cle not in self._tables:
            raise KeyError(cle)
        self.fluide = cle

    # ─────────────────── Modèle ───────────────────

    def _point_de_fonctionnement(self) -> dict:
        """Point de fonctionnement courant : nominal + défauts + respiration."""
        pf = dict(NOMINAL)
        for cle in self._defauts_actifs:
            for grandeur, ecart in DEFAUTS[cle]["effets"].items():
                pf[grandeur] += ecart

        # Le banc respire : oscillation lente du condenseur, bruit sur le reste.
        t = time.time() - self._t0
        pf["t_condensation"] += 1.6 * math.sin(t / 47.0)
        pf["t_evaporation"] += 0.9 * math.sin(t / 31.0 + 1.2)
        pf["surchauffe"] += 0.5 * math.sin(t / 23.0 + 0.4)
        pf["ambiance_froid"] += 0.7 * math.sin(t / 61.0)

        # Garde-fous physiques : une surchauffe ne descend pas sous zéro, et le
        # sous-refroidissement ne peut pas être négatif non plus.
        pf["surchauffe"] = max(0.2, pf["surchauffe"])
        pf["sous_refroidissement"] = max(0.0, pf["sous_refroidissement"])
        return pf

    def _valeurs_par_emplacement(self, pf: dict) -> dict:
        sat = self._tables[self.fluide]["sat"]
        p_bp = _pression_pour_temperature(sat, pf["t_evaporation"], "tr")
        p_hp = _pression_pour_temperature(sat, pf["t_condensation"], "tb")

        t_sortie_evap = pf["t_evaporation"] + pf["surchauffe"]
        t_sortie_cond = pf["t_condensation"] - pf["sous_refroidissement"]

        return {
            # Les manomètres mesurent en pression relative, comme sur le terrain.
            "bp": p_bp - PRESSION_ATMO,
            "hp": p_hp - PRESSION_ATMO,
            "sortie_evaporateur": t_sortie_evap,
            "entree_compresseur": t_sortie_evap + pf["rechauffement_aspiration"],
            "sortie_condenseur": t_sortie_cond,
            "entree_detendeur": t_sortie_cond - pf["refroidissement_liquide"],
            "air_reprise_condenseur": pf["air_reprise_condenseur"],
            "air_souffle_condenseur": pf["air_reprise_condenseur"] + pf["ecart_air_condenseur"],
            "ambiance_froid": pf["ambiance_froid"],
        }

    def _boucle(self) -> None:
        while self._tourne:
            pf = self._point_de_fonctionnement()
            valeurs = self._valeurs_par_emplacement(pf)
            maintenant = time.time()

            with self._verrou:
                for serie, modele, grandeur, emplacement in PARC:
                    if serie in self._sondes_coupees:
                        ancienne = self._mesures.get(serie)
                        self._mesures[serie] = Mesure(
                            serie=serie, modele=modele, grandeur=grandeur,
                            valeur=None, unite="bar" if grandeur == "pression" else "°C",
                            etat=PERDUE, batterie=self._batteries[serie],
                            horodatage=ancienne.horodatage if ancienne else 0.0,
                        )
                        continue

                    bruit = random.gauss(0, 0.02 if grandeur == "pression" else 0.08)
                    valeur = valeurs[emplacement] + bruit
                    self._mesures[serie] = Mesure(
                        serie=serie, modele=modele, grandeur=grandeur,
                        valeur=round(valeur, 2),
                        unite="bar" if grandeur == "pression" else "°C",
                        etat=CONNECTEE, batterie=self._batteries[serie],
                        horodatage=maintenant, rssi=random.randint(-78, -52),
                    )

            time.sleep(1.0)
