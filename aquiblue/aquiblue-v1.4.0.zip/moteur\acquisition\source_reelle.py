# inerWeb AquiBlue — GPL-3.0 (voir LICENSE).
"""
Source d'acquisition RÉELLE — les sondes Bluetooth, conformes au contrat
`SourceAcquisition` (lot 3 du dossier de mise en conformité).

Le scan, la connexion et le décodage vivent dans le serveur (déjà testés) :
cette classe en donne la VUE conforme au contrat, en convertissant les fiches
de sondes en objets `Mesure` porteurs de leur provenance (REEL), de leur
fraîcheur (âge, qualité) et de leur état de liaison. Elle applique aussi la
tare de pression, sans jamais mélanger avec la simulation.

Elle ne fabrique aucune donnée : si une sonde n'a rien envoyé, elle n'émet
rien pour cette grandeur.
"""

import time

from .base import CONNECTEE, PERDUE, REEL, EtatSource, Mesure

# Au-delà de ce délai sans nouvelle trame, une mesure est déclarée PÉRIMÉE :
# la couche haute refusera de l'interpréter.
SEUIL_PERIME_S = 8.0

# Grandeurs qui alimentent le cycle (la batterie est une méta, pas un point).
GRANDEURS_CYCLE = ("temperature", "pression", "vitesse", "humidite")


class SourceBleReelle:
    """Vue `SourceAcquisition` sur les sondes réellement connectées.

    `registre()` renvoie le dict {adresse: fiche} tenu par le serveur.
    `offsets()` renvoie le dict {adresse: offset_pression} de l'étalonnage.
    """

    def __init__(self, registre, offsets):
        self._registre = registre
        self._offsets = offsets

    # ─────────────── Interface SourceAcquisition ───────────────

    def demarrer(self) -> None:
        pass   # le cycle de vie des sondes est piloté par le serveur

    def arreter(self) -> None:
        pass

    def lire(self) -> list[Mesure]:
        maintenant = time.time()
        offsets = self._offsets()
        mesures = []
        for adresse, fiche in list(self._registre().items()):
            etat_liaison = fiche.get("etat")
            brut = fiche.get("mesures", {})
            batterie = None
            if "batterie" in brut:
                try:
                    batterie = int(round(brut["batterie"]["valeur"]))
                except (TypeError, ValueError):
                    batterie = None
            horo = fiche.get("derniere_mesure", 0) or 0
            age_ms = int((maintenant - horo) * 1000) if horo else -1

            for grandeur in GRANDEURS_CYCLE:
                m = brut.get(grandeur)
                if m is None:
                    continue
                valeur = m["valeur"]
                # Tare de pression : on retranche l'offset mémorisé à l'air libre.
                if grandeur == "pression" and offsets.get(adresse) is not None:
                    valeur = round(valeur - offsets[adresse], 3)

                connectee = etat_liaison == "connectee"
                if not connectee:
                    valeur = None
                mesures.append(Mesure(
                    serie=fiche["nom"], modele="sonde réelle", grandeur=grandeur,
                    valeur=valeur, unite=m["unite"],
                    etat=CONNECTEE if connectee else PERDUE,
                    source=REEL, batterie=batterie,
                    horodatage=horo, age_ms=age_ms,
                ))
        return mesures

    def etat(self) -> EtatSource:
        registre = self._registre()
        connectees = sum(1 for f in registre.values() if f.get("etat") == "connectee")
        avertissements = []
        perdues = [f["nom"] for f in registre.values() if f.get("etat") == "perdue"]
        if perdues:
            avertissements.append("Liaison perdue : " + ", ".join(perdues))
        return EtatSource(
            nom="Sondes Bluetooth réelles",
            active=len(registre) > 0,
            detail=f"{connectees}/{len(registre)} sonde(s) connectée(s)",
            sondes_attendues=len(registre),
            sondes_connectees=connectees,
            avertissements=avertissements,
        )

    # ─────────────── Aide à la couche haute ───────────────

    @staticmethod
    def qualite(mesure: Mesure) -> str:
        """Qualité d'une mesure réelle : ok / perimee / perdue."""
        if mesure.etat != CONNECTEE or mesure.valeur is None:
            return "perdue"
        if mesure.age_ms < 0 or mesure.age_ms > SEUIL_PERIME_S * 1000:
            return "perimee"
        return "ok"
