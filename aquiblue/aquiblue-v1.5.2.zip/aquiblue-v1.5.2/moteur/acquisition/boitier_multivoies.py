# inerWeb AquiBlue — GPL-3.0 (voir LICENSE).
"""
Famille « boîtier multivoies » — six sondes filaires de température sur un
seul boîtier Bluetooth.

Deuxième famille de capteurs du banc, à côté des sondes autonomes décodées
dans `protocole_reel.py`. Les deux ne partagent rien : ni service GATT, ni
format de trame, ni séquence d'ouverture. C'est précisément pourquoi
l'architecture prévoit un module par famille.

CE QUE CE BOÎTIER SAIT FAIRE
    Six points de température simultanés pour le prix d'une sonde autonome.
    Utile sur la branche haute pression (refoulement, condenseur, liquide),
    sur l'air de climatisation, sur les circuits d'eau et sur l'échauffement
    des conducteurs.

CE QU'IL NE SAIT PAS FAIRE — LIMITE DURE, VÉRIFIÉE LE 28/08/2026
    Il ne mesure RIEN en dessous de 1 °C. La borne est dans le firmware du
    boîtier, pas dans la sonde : aucun contournement logiciel n'existe.
    Évaporateur, aspiration, surchauffe et chambres négatives restent donc
    le domaine exclusif des sondes autonomes. Ne jamais proposer une voie de
    ce boîtier pour un point de mesure susceptible de passer sous zéro.

PROTOCOLE (percé in situ le 28/08/2026, journal dans outils/decouverte-ble)
    Service ffb0, caractéristique ffb2 en notification. AUCUNE séquence
    d'ouverture : on s'abonne, le boîtier émet spontanément une trame toutes
    les 2 à 3 secondes.

    55 00 | CH1 | CH2 | CH3 | CH4 | CH5 | CH6 | 00        (15 octets)
      │      └── deux octets gros-boutistes, en dixièmes de degré Celsius
      │          0x00FE = 254 = 25,4 °C ; 0xFFFF = prise vide
      └── en-tête constant

    Le dernier octet n'a pas été identifié (constant à 00 sur tous les
    relevés) : il est ignoré. Correspondance des prises vérifiée par
    débranchement successif — le marquage CH1..CH6 du boîtier suit l'ordre
    des paires d'octets.
"""

# Service et caractéristique propres à cette famille.
UUID_SERVICE = "0000ffb0-0000-1000-8000-00805f9b34fb"
UUID_NOTIFY = "0000ffb2-0000-1000-8000-00805f9b34fb"

EN_TETE = 0x55
DECALAGE_VOIES = 2
NB_VOIES = 6
TAILLE_MINIMALE = DECALAGE_VOIES + 2 * NB_VOIES
PRISE_VIDE = 0xFFFF

# Plage annoncée par le constructeur et confirmée à l'essai. Hors de ces
# bornes, la valeur n'est pas une température : on ne la publie pas.
TEMPERATURE_MIN = 1.0
TEMPERATURE_MAX = 300.0


def est_trame_boitier(data: bytes) -> bool:
    """Reconnaît une trame de cette famille sans se fier au nom de l'appareil.

    Le nom d'annonce n'est pas fiable (il varie d'un lot à l'autre) : on
    valide sur la forme de la trame, qui est stable.
    """
    return len(data) >= TAILLE_MINIMALE and data[0] == EN_TETE


def decoder(data: bytes) -> list[tuple[int, float | None]]:
    """Rend les six voies, dans l'ordre des prises CH1 à CH6.

    Une voie vaut `None` quand la prise est vide, ou quand la valeur reçue
    sort de la plage physique du boîtier — un capteur débranché à chaud
    passe par des valeurs aberrantes avant d'annoncer la prise vide, et une
    température fantaisiste affichée à l'élève serait pire que rien.
    """
    if not est_trame_boitier(data):
        return []

    voies: list[tuple[int, float | None]] = []
    for numero in range(1, NB_VOIES + 1):
        debut = DECALAGE_VOIES + 2 * (numero - 1)
        brut = int.from_bytes(data[debut:debut + 2], "big")
        if brut == PRISE_VIDE:
            voies.append((numero, None))
            continue
        temperature = brut / 10.0
        if not TEMPERATURE_MIN <= temperature <= TEMPERATURE_MAX:
            voies.append((numero, None))
            continue
        voies.append((numero, temperature))
    return voies


def voies_occupees(data: bytes) -> int:
    """Nombre de sondes effectivement branchées, pour l'affichage d'état."""
    return sum(1 for _, valeur in decoder(data) if valeur is not None)


# ─────────────── Publication des voies vers la couche haute ───────────────
#
# Les six voies n'ont AUCUN numéro de série propre : le boîtier en a un, les
# prises n'en ont pas. C'est donc la PRISE qui les désigne — CH1 à CH6, tel
# que marqué sur le boîtier. L'élève lit la prise et la tape à l'affectation,
# exactement comme il lit un numéro de série sur une sonde autonome.

PREFIXE_GRANDEUR = "temperature_ch"
UNITE = "°C"


def est_famille_boitier(uuids) -> bool:
    """Reconnaît la famille aux services annoncés par l'appareil connecté.

    On interroge le GATT plutôt que le nom d'annonce : le nom varie d'un lot
    à l'autre, le service non.
    """
    return UUID_SERVICE.lower() in {str(u).lower() for u in uuids}


def grandeur_de_voie(numero: int) -> str:
    """Nom de grandeur publié pour la prise `numero` (1 à 6)."""
    return f"{PREFIXE_GRANDEUR}{numero}"


def numero_de_grandeur(grandeur: str) -> int | None:
    """Numéro de prise porté par un nom de grandeur, ou None."""
    if not grandeur.startswith(PREFIXE_GRANDEUR):
        return None
    suffixe = grandeur[len(PREFIXE_GRANDEUR):]
    return int(suffixe) if suffixe.isdigit() else None


def libelle_de_voie(numero: int) -> str:
    """Ce que l'élève lit à l'écran et retrouve marqué sur le boîtier."""
    return f"CH{numero}"


def mesures_depuis_trame(data: bytes) -> dict:
    """Traduit une trame en entrées de registre, une par prise.

    Rend les SIX voies, y compris celles qui valent None (prise vide, sonde
    débranchée, valeur hors plage). L'appelant doit retirer les voies à None
    de sa fiche : sans cela, la dernière valeur connue d'une sonde arrachée
    resterait affichée à l'élève comme une mesure vivante.
    """
    fiche: dict = {}
    for numero, valeur in decoder(data):
        nom = grandeur_de_voie(numero)
        fiche[nom] = None if valeur is None else {"valeur": valeur, "unite": UNITE}
    return fiche
