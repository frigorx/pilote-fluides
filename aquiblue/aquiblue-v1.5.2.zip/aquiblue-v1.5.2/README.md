# inerWeb AquiBlue — Acquisition de données Bluetooth

Banc de mesure pédagogique : des sondes Bluetooth du commerce (température,
pression, air) tracent le **cycle frigorifique en direct** sur un diagramme
enthalpique. Pensé pour les ateliers froid et climatisation (CAP, Bac Pro,
BTS), du premier branchement au diagnostic de panne.

Outil indépendant, non affilié à un fabricant d'instruments.

**Logiciel libre et gratuit — licence GPL-3.0** (voir `LICENSE`).
La séquence d'initialisation des sondes dérive du projet
[`testo405i_mqtt`](https://github.com/VladimirHulagov) de Vladimir Hulagov
(GPL-3.0) : ce projet entier est distribué sous la même licence, comme elle
l'exige. Merci à lui.

## Lancer

**Sans rien installer (simulation)** : double-cliquer `web/index.html`.
La page est autonome — tables thermodynamiques embarquées, simulation
intégrée, aucun réseau. Bandeau orange permanent : les valeurs sont simulées.

**Avec les vraies sondes** :

```bash
pip install bleak
python serveur.py
```

Le navigateur s'ouvre sur `http://127.0.0.1:2015/` (poste élève : le pupitre
d'injection de défauts est masqué ; poste professeur : `?prof=1`).
Une sonde allumée apparaît toute seule → « Ajouter au banc » → taper son
numéro de série en face du point de mesure → le cycle se dessine.
Prérequis : Windows 10 (1709+) ou 11, Bluetooth 4.0+ (dongle USB conseillé),
Python 3.12+.

## Ce que fait le banc

- Diagramme de Mollier animé, 4 fluides (R-134a, R-404A, R-449A, R-290) ;
  surchauffe et surchauffe totale (sur la rosée), sous-refroidissement et
  total (sur la bulle), taux de compression, ΔT air.
- **Utilitaires de mesure** : DT1, pincement d'évaporateur, écart et approche
  au condenseur, efficacités d'échangeur, puissances côté air et côté eau,
  COP mesuré, COP de Carnot, rendement rapporté à cette limite. Chaque
  grandeur affiche **sa formule** et, quand une entrée manque, reste vide en
  **nommant ce qui manque** : rien n'est estimé, rien n'est complété.
- **Douze configurations de pose** : choisir la sienne ne montre que ses
  points de mesure, les renomme selon la pose, rappelle ce qu'il faut relever
  à la main, et masque les grandeurs que la pose ne permet pas de calculer.
- **Profil de température le long d'un échangeur** : six sondes simultanées
  donnent une forme, pas six nombres. Sur un évaporateur, la forme localise
  l'endroit où la surchauffe commence — le réglage du détendeur rendu
  visible. La zone de changement d'état est tracée, glissement compris : sur
  un mélange zéotrope la température monte de plusieurs kelvins sans la
  moindre surchauffe, et l'ignorer ferait lire une surchauffe inexistante.
- **Dispersion** d'un groupe de sondes à côté de sa moyenne — la moyenne
  cache un défaut de distribution que l'écart révèle.
- Modes SIMULATION / RÉEL jamais mélangés : chaque valeur porte sa
  provenance et sa fraîcheur ; une mesure périmée n'alimente pas le cycle.
- 5 défauts injectables côté professeur, l'élève diagnostique à l'aveugle.
- Enregistrement, rejeu accéléré (×5 à ×60), export CSV, relevé PDF.
- Saisie manuelle de tout point (pression relative/absolue ou température
  de saturation) quand un appareil manque — les manomètres fixes de l'atelier
  suffisent — et relevés à la main du débit d'air, du débit d'eau et de la
  puissance électrique **active**, qu'aucune sonde ne donne.
- Tare des manomètres persistée, journaux de capture bornés et effaçables,
  tout fonctionne **hors ligne** : aucune donnée ne quitte le poste.

## Pour les enseignants

Les plans de séance, la feuille de guidance élève et la fiche de relevé
(hybride numérique + papier) sont diffusés à part, sur demande par e-mail :
**inerweb.fh@gmail.com**, objet « AquiBlue — demande de code ».

## Architecture

```
serveur.py               pont HTTP local durci (127.0.0.1, actions en POST)
acquisition/
  base.py                contrat commun SourceAcquisition
  simulateur.py          source simulée (repli sans matériel)
  protocole_reel.py      décodage des sondes autonomes (handshake + trames)
  boitier_multivoies.py  décodage d'un boîtier à six sondes filaires
  source_reelle.py       vue temps réel conforme au contrat
web/index.html           interface complète, autonome
web/fluides.json         tables thermodynamiques (CoolProp 8.0.0, IIR)
outils/                  génération des tables, construction du paquet
tests/                   48 tests (décodage, exactitude ≤ 7 mK, sécurité)
```

Règle d'architecture : **un module d'acquisition par famille de capteurs**,
tous derrière la même interface — les familles futures (filaire 4-20 mA,
autres sondes BLE) s'ajoutent sans toucher au reste. Deux familles sont
gérées : les sondes autonomes, qui exigent une séquence d'ouverture, et un
boîtier à six sondes filaires, qui émet spontanément. La famille se reconnaît
au service GATT, jamais au nom d'annonce — celui-ci varie d'un lot à l'autre.

**Une limite de matériel devenue une règle du logiciel.** Le boîtier six
voies ne mesure rien en dessous de 1 °C. Une de ses voies affectée à un point
qui peut passer sous zéro est donc refusée — mais seulement si l'installation
mesurée est réellement froide, ce que la basse pression dit. Sur une
climatisation ou une chambre positive, l'évaporation est au-dessus de zéro et
le boîtier convient : un refus systématique aurait interdit son meilleur
usage. C'est le seul endroit du programme où une affectation est empêchée ;
partout ailleurs l'erreur est permise, parce que le diagramme la révèle.

## Licence

GPL-3.0 (`LICENSE`). Vous pouvez utiliser, étudier, modifier et redistribuer
ce logiciel, y compris vos versions modifiées, aux conditions de la GPL :
mêmes libertés pour les destinataires, sources incluses, mentions conservées.
Fourni sans garantie ; les valeurs affichées dépendent des sondes et de leur
pose — cet outil pédagogique ne remplace aucun instrument réglementaire.
