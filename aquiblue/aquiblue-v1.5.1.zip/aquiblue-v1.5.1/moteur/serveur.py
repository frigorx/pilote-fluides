# inerWeb AquiBlue — logiciel libre sous GPL-3.0 (voir LICENSE).
# La séquence d'initialisation des sondes dérive de testo405i_mqtt
# (Vladimir Hulagov, GPL-3.0) — attribution : NOTICE-TIERS.md.
"""
Pont local entre la source d'acquisition et la page web d'AquiBlue.
Reprend le principe du web_bridge.py du projet AK-CC 550 : serveur HTTP sur
la boucle locale, API JSON, ouverture automatique du navigateur.

    python serveur.py              mode simulation par défaut
    python serveur.py --port 2015  autre port

Durcissement (Lot 5 du dossier de conformité) :
  - toutes les actions passent en POST (le GET ne modifie jamais rien) ;
  - chaque paramètre est validé strictement avant usage ;
  - l'origine des requêtes est contrôlée (Host et Origin locaux) ;
  - en-têtes de sécurité sur toutes les réponses ;
  - les cellules de journaux CSV sont neutralisées (anti-injection tableur) ;
  - journaux bornés, purgeables, rangés dans le dossier utilisateur ;
  - les exceptions sont journalisées, plus jamais avalées en silence ;
  - arrêt propre (Ctrl+C ou POST /api/arreter), sans processus résiduel.
"""

import argparse
import asyncio
import csv
import json
import logging
import logging.handlers
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime
from dataclasses import asdict
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from acquisition.simulateur import SimulateurBanc
from acquisition.source_reelle import SourceBleReelle
from acquisition.protocole_reel import LecteurTrames, SEQUENCE_INIT, UUID_ECRITURE, UUID_NOTIFY
from acquisition.boitier_multivoies import (
    est_famille_boitier, mesures_depuis_trame,
    UUID_NOTIFY as UUID_NOTIFY_BOITIER)

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

DOSSIER_WEB = Path(__file__).resolve().parent / "web"
PORT_DEFAUT = 2015

# ─────────────── Données locales : dossier utilisateur (Lot 5) ───────────────
# Les données produites (journaux de capture, étalonnage, journal technique)
# ne vivent plus dans le dossier du programme : elles vont dans le profil de
# l'utilisateur, documenté dans REGISTRE-DONNEES-LOCALES.md. Ainsi le dossier
# du programme reste en lecture seule de fait, et une synchronisation type
# OneDrive du programme n'emporte plus les données.
DOSSIER_DONNEES = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "banc-acquisition-ble"
DOSSIER_JOURNAUX = DOSSIER_DONNEES / "journaux"
FICHIER_ETALONNAGE = DOSSIER_DONNEES / "etalonnage.json"
ANCIEN_ETALONNAGE = Path(__file__).resolve().parent / "etalonnage.json"

# Bornes des journaux : un fichier de capture s'arrête à 5 Mo, et le dossier
# tourne sur les 100 fichiers les plus récents. La purge complète reste un
# geste volontaire (POST /api/journaux/purger).
TAILLE_MAX_JOURNAL = 5 * 1024 * 1024
NB_MAX_JOURNAUX = 100

journal = logging.getLogger("banc")


def _preparer_journal_technique():
    """Journal technique borné (2 × 512 Ko) dans le dossier utilisateur."""
    DOSSIER_DONNEES.mkdir(parents=True, exist_ok=True)
    gestionnaire = logging.handlers.RotatingFileHandler(
        DOSSIER_DONNEES / "banc.log", maxBytes=512 * 1024, backupCount=1,
        encoding="utf-8")
    gestionnaire.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    journal.addHandler(gestionnaire)
    journal.setLevel(logging.INFO)


def purger_journaux(tout=False):
    """Rotation (garde les NB_MAX_JOURNAUX plus récents) ou purge complète."""
    if not DOSSIER_JOURNAUX.exists():
        return 0
    fichiers = sorted(DOSSIER_JOURNAUX.glob("*.csv"),
                      key=lambda f: f.stat().st_mtime, reverse=True)
    a_supprimer = fichiers if tout else fichiers[NB_MAX_JOURNAUX:]
    for f in a_supprimer:
        try:
            f.unlink()
        except OSError as e:
            journal.warning("purge impossible pour %s : %s", f.name, e)
    if a_supprimer:
        journal.info("journaux purgés : %d fichier(s)%s", len(a_supprimer),
                     " (purge complète demandée)" if tout else " (rotation)")
    return len(a_supprimer)


def neutraliser_csv(texte: str) -> str:
    """Anti-injection tableur : une cellule ne doit jamais commencer par un
    caractère de formule. L'étiquette décodée vient de la radio : elle n'est
    pas de confiance."""
    return "'" + texte if texte[:1] in ("=", "+", "-", "@", "\t") else texte


# ─────────────── Validation stricte des entrées (Lot 5) ───────────────
# Tout paramètre reçu par l'API est contrôlé ici avant d'être utilisé.
RE_ADRESSE_BLE = re.compile(r"^[0-9A-Fa-f]{2}([:-][0-9A-Fa-f]{2}){5}$")
RE_CLE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")   # clés réelles : « R134a », « givre_evaporateur »…
RE_SERIE = re.compile(r"^[A-Za-z0-9 ._:-]{1,32}$")
RE_NOM_PROPRE = re.compile(r"[^A-Za-z0-9 ._:-]")


def adresse_valide(v) -> bool:
    return isinstance(v, str) and bool(RE_ADRESSE_BLE.match(v))


def cle_valide(v) -> bool:
    return isinstance(v, str) and bool(RE_CLE.match(v))


def serie_valide(v) -> bool:
    return isinstance(v, str) and bool(RE_SERIE.match(v))


def assainir_nom(v) -> str:
    """Nom d'annonce Bluetooth : contrôlé par l'émetteur radio, donc jamais
    de confiance. On ne laisse passer qu'un alphabet sûr, borné à 40 signes,
    AVANT toute exposition à la page (anti-XSS par un périphérique forgé)."""
    if not isinstance(v, str):
        return "sonde"
    propre = RE_NOM_PROPRE.sub("", v).strip()
    return propre[:40] or "sonde"


# Deux sources, jamais mélangées. Le MODE dit laquelle alimente le cycle,
# le diagramme, l'enregistrement et l'export. La simulation ne peut pas
# contaminer le réel : ce sont deux objets distincts.
source_sim = SimulateurBanc()
# La source réelle lit les fiches de sondes et l'étalonnage (définis plus bas) ;
# les lambdas résolvent ces globales au moment de la lecture.
source_reelle = SourceBleReelle(lambda: sondes_validees, lambda: offsets_pression)
MODES = ("SIMULATION", "REEL")
mode_actif = "SIMULATION"


def source_active():
    return source_reelle if mode_actif == "REEL" else source_sim


# ─────────────────── Surveillance du Bluetooth réel ───────────────────
# Scan permanent en tâche de fond : l'utilisateur allume une sonde, elle
# apparaît dans la page quelques secondes plus tard, sans aucune manœuvre.

etat_bluetooth = {
    "disponible": None,      # None = premier scan pas terminé
    "detail": "Premier scan en cours…",
    "adaptateur": "",
    "appareils": [],         # tout ce qui émet autour : [{nom, adresse}]
    "sondes": [],            # sous-ensemble reconnu comme sonde de mesure
    "horodatage": 0,
}
_verrou_bt = threading.Lock()


def _nom_adaptateur():
    """Nom du module Bluetooth du PC, via le gestionnaire de périphériques."""
    try:
        # PowerShell sort dans l'encodage console OEM : on force l'UTF-8 des
        # deux côtés, sinon le décodage plante sur les accents et on perd tout.
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
             "Get-PnpDevice -Class Bluetooth -Status OK | "
             "Select-Object -ExpandProperty FriendlyName"],
            capture_output=True, text=True, timeout=15,
            encoding="utf-8", errors="replace")
        noms = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        for n in noms:
            bas = n.lower()
            if "adapter" in bas or "radio" in bas or "wireless bluetooth" in bas:
                return n
        return noms[0] if noms else ""
    except Exception as e:
        journal.warning("nom d'adaptateur Bluetooth illisible : %s", e)
        return ""


# Sondes validées par l'utilisateur (geste « Ajouter au banc ») :
# adresse -> {nom, etat, trames, fichier}. La boucle de vie de chaque sonde
# tourne dans la boucle asyncio du thread Bluetooth ; l'API HTTP y poste ses
# demandes via _boucle_asyncio.
sondes_validees = {}
_boucle_asyncio = None

# Étalonnage : mise à zéro (tare) des manomètres. On mémorise, par sonde, la
# pression lue au moment du « Mettre à 0 » (sonde à l'air libre) et on la
# retranche ensuite. Persisté sur disque pour survivre à un redémarrage.
offsets_pression = {}


def _charger_offsets():
    """Lit l'étalonnage du dossier utilisateur ; migre une seule fois celui
    de l'ancien emplacement (dossier du programme) s'il existe encore."""
    global offsets_pression
    try:
        if not FICHIER_ETALONNAGE.exists() and ANCIEN_ETALONNAGE.exists():
            DOSSIER_DONNEES.mkdir(parents=True, exist_ok=True)
            FICHIER_ETALONNAGE.write_text(
                ANCIEN_ETALONNAGE.read_text(encoding="utf-8"), encoding="utf-8")
            ANCIEN_ETALONNAGE.unlink()
            journal.info("étalonnage migré vers %s", FICHIER_ETALONNAGE)
        offsets_pression = json.loads(FICHIER_ETALONNAGE.read_text(encoding="utf-8"))
        if not isinstance(offsets_pression, dict):
            raise ValueError("format inattendu")
    except FileNotFoundError:
        offsets_pression = {}
    except Exception as e:
        journal.warning("étalonnage illisible (%s), repart à vide", e)
        offsets_pression = {}


def _sauver_offsets():
    try:
        DOSSIER_DONNEES.mkdir(parents=True, exist_ok=True)
        FICHIER_ETALONNAGE.write_text(json.dumps(offsets_pression), encoding="utf-8")
    except OSError as e:
        journal.error("étalonnage non sauvegardé : %s", e)


async def _vie_d_une_sonde(adresse: str):
    """Connexion, abonnements, journal ; reconnexion tant que la sonde est
    validée. Un échec ici ne touche jamais les autres sondes."""
    from bleak import BleakClient

    fiche = sondes_validees.get(adresse)
    if fiche is None:
        return
    DOSSIER_JOURNAUX.mkdir(parents=True, exist_ok=True)
    nom_court = re.sub(r"[^A-Za-z0-9]+", "-", fiche["nom"]).strip("-") or "sonde"
    horodatage = datetime.now().strftime("%Y%m%d_%H%M%S")
    chemin = DOSSIER_JOURNAUX / f"{nom_court}_{horodatage}.csv"
    fiche["fichier"] = chemin.name

    with open(chemin, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["horodatage", "octets_hex", "grandeurs_decodees"])
        lecteur = LecteurTrames()
        journal_plein = False

        def notification(caracteristique, data: bytearray):
            nonlocal journal_plein
            fiche["trames"] += 1
            octets = bytes(data)
            if fiche.get("famille") == "boitier":
                # Six voies : aucun reassemblage, une trame = un releve
                # complet. Une prise vide EFFACE sa voie, sinon la
                # derniere valeur d'une sonde arrachee resterait affichee
                # a l'eleve comme une mesure vivante.
                trouves = []
                for grandeur, mesure in mesures_depuis_trame(octets).items():
                    if mesure is None:
                        fiche["mesures"].pop(grandeur, None)
                        continue
                    fiche["mesures"][grandeur] = mesure
                    fiche["derniere_mesure"] = time.time()
                    trouves.append((grandeur, mesure["valeur"], mesure["unite"]))
            else:
                trouves = lecteur.alimenter(octets)
                for grandeur, valeur, unite in trouves:
                    fiche["mesures"][grandeur] = {"valeur": valeur, "unite": unite}
                    fiche["derniere_mesure"] = time.time()
            if journal_plein:
                return
            if f.tell() > TAILLE_MAX_JOURNAL:
                writer.writerow(["", "", "journal tronqué : taille maximale atteinte"])
                f.flush()
                journal_plein = True
                journal.info("journal de %s tronqué à %d octets", adresse, f.tell())
                return
            writer.writerow([
                datetime.now().strftime("%H:%M:%S.%f")[:-3],
                bytes(data).hex(" "),
                neutraliser_csv(" | ".join(f"{g}={v}{u}" for g, v, u in trouves)),
            ])
            f.flush()

        while adresse in sondes_validees:
            try:
                fiche["etat"] = "connexion"
                async with BleakClient(adresse, timeout=15.0) as client:
                    fiche["etat"] = "connectee"
                    # Quelle famille de capteurs ? La question se pose au
                    # GATT, jamais au nom d'annonce (qui varie d'un lot a
                    # l'autre). Les deux familles ne partagent ni service,
                    # ni format de trame, ni sequence d'ouverture.
                    boitier = est_famille_boitier(
                        [s.uuid for s in client.services])
                    fiche["famille"] = "boitier" if boitier else "autonome"
                    # Abonnement à la voie de réponse.
                    try:
                        await client.start_notify(
                            UUID_NOTIFY_BOITIER if boitier else UUID_NOTIFY,
                            notification)
                    except Exception as e:
                        journal.info("notify standard refusé sur %s (%s), repli", adresse, e)
                        # Repli : tout ce qui notifie (sondes atypiques).
                        for service in client.services:
                            for car in service.characteristics:
                                if "notify" in car.properties:
                                    try:
                                        await client.start_notify(car, notification)
                                    except Exception as e2:
                                        journal.debug("notify %s refusé : %s", car.uuid, e2)
                    # Handshake d'init : sans lui, la sonde autonome ne
                    # renvoie qu'un accuse fige. Le boitier multivoies, lui,
                    # emet spontanement des l'abonnement : lui ecrire cette
                    # sequence n'aurait aucun sens.
                    for hexa in (() if boitier else SEQUENCE_INIT):
                        try:
                            await client.write_gatt_char(UUID_ECRITURE, bytes.fromhex(hexa), response=True)
                        except Exception:
                            try:
                                await client.write_gatt_char(UUID_ECRITURE, bytes.fromhex(hexa), response=False)
                            except Exception as e:
                                journal.debug("écriture init refusée sur %s : %s", adresse, e)
                        await asyncio.sleep(0.4)
                    while client.is_connected and adresse in sondes_validees:
                        await asyncio.sleep(1.0)
            except Exception as e:
                fiche["erreurs"] = fiche.get("erreurs", 0) + 1
                journal.warning("sonde %s : %s", adresse, e)
            if adresse in sondes_validees:
                fiche["etat"] = "perdue"
                await asyncio.sleep(3.0)   # nouvelle tentative, sans gêner le reste
    journal.info("fin de suivi de la sonde %s", adresse)


def valider_sonde(adresse: str, nom: str) -> bool:
    """Appelé par l'API HTTP : prend la sonde en charge dans le thread BLE.
    L'adresse et le nom arrivent déjà validés/assainis par le handler."""
    if _boucle_asyncio is None or adresse in sondes_validees:
        return False
    sondes_validees[adresse] = {"nom": nom, "etat": "connexion", "trames": 0,
                                "fichier": "", "mesures": {}, "derniere_mesure": 0,
                                "famille": ""}
    asyncio.run_coroutine_threadsafe(_vie_d_une_sonde(adresse), _boucle_asyncio)
    return True


def retirer_sonde(adresse: str) -> bool:
    return sondes_validees.pop(adresse, None) is not None


def _boucle_scan_bluetooth():
    global _boucle_asyncio
    try:
        from bleak import BleakScanner
    except ImportError:
        with _verrou_bt:
            etat_bluetooth.update(
                disponible=False,
                detail="Le module Python « bleak » n'est pas installé "
                       "(pip install bleak).")
        return

    adaptateur = _nom_adaptateur()
    with _verrou_bt:
        etat_bluetooth["adaptateur"] = adaptateur

    async def cycle():
        global _boucle_asyncio
        _boucle_asyncio = asyncio.get_running_loop()
        while True:
            try:
                appareils = await BleakScanner.discover(timeout=4.0)
                # Les noms d'annonce sont assainis dès l'entrée : c'est de la
                # donnée radio, elle ne doit jamais atteindre la page telle
                # quelle (voir assainir_nom).
                vus = sorted(
                    [{"nom": assainir_nom(a.name or "(sans nom)"), "adresse": a.address}
                     for a in appareils],
                    key=lambda v: v["nom"].lower())
                # Filtre technique d'interopérabilité : les sondes visées
                # s'annoncent « T115i SN:12345678 », « T410i… », « T915i… »
                # (constaté en réel le 22/08), parfois avec le nom du fabricant.
                sondes = [v for v in vus
                          if re.match(r"^t\d{3}i\b", v["nom"].lower())
                          or "testo" in v["nom"].lower()]
                with _verrou_bt:
                    etat_bluetooth.update(
                        disponible=True, detail="", appareils=vus,
                        sondes=sondes, horodatage=time.time())
            except Exception as e:
                journal.warning("scan Bluetooth en échec : %s", e)
                with _verrou_bt:
                    etat_bluetooth.update(
                        disponible=False, appareils=[], sondes=[],
                        detail="Bluetooth coupé ou absent. Activez-le : "
                               "Paramètres Windows → Bluetooth et appareils.",
                        horodatage=time.time())
            await asyncio.sleep(2.0)

    asyncio.run(cycle())


# ─────────────────────────── Serveur HTTP ───────────────────────────

TAILLE_MAX_CORPS = 4096          # un ordre d'action tient très en dessous
_serveur_http = None             # rempli par main(), pour l'arrêt propre


class Pont(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DOSSIER_WEB), **kwargs)

    # En-têtes de sécurité sur TOUTES les réponses (fichiers compris).
    # La page est autonome (styles et scripts embarqués), d'où unsafe-inline ;
    # connect-src 'self' suffit : la page ne parle qu'au serveur local.
    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; script-src 'self' 'unsafe-inline'; "
                         "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                         "connect-src 'self'; frame-ancestors 'none'; "
                         "form-action 'self'; base-uri 'none'")
        super().end_headers()

    # ── Garde locale : Host (anti-rebinding DNS) et Origin (anti-CSRF) ──
    def _hote_local(self) -> bool:
        hote = (self.headers.get("Host") or "").strip().lower()
        return hote.startswith("127.0.0.1") or hote.startswith("localhost")

    def _origine_locale(self) -> bool:
        origine = self.headers.get("Origin")
        if origine is None:           # outil local (curl…) : pas d'Origin
            return True
        o = urlparse(origine)
        return o.hostname in ("127.0.0.1", "localhost")

    ROUTES_ACTION = ("/api/mode", "/api/valider", "/api/devalider", "/api/tare",
                     "/api/tare_annuler", "/api/defaut", "/api/sonde",
                     "/api/fluide", "/api/reinitialiser", "/api/journaux/purger",
                     "/api/arreter")

    def do_GET(self):
        if not self._hote_local():
            self._erreur(403, "Requête refusée : hôte non local.")
            return
        chemin = urlparse(self.path)

        if chemin.path == "/api/bluetooth":
            with _verrou_bt:
                reponse = dict(etat_bluetooth)
            # Fusion scan + sondes validées : une sonde CONNECTÉE n'émet plus
            # d'annonce Bluetooth, elle disparaît donc du scan — sans cette
            # fusion elle s'évanouirait de l'écran au moment même où ça marche.
            def _resume(adresse, nom, fiche, etat_defaut):
                mesures = dict(fiche["mesures"]) if fiche else {}
                # Applique la tare sur la pression, sans altérer la valeur brute
                # stockée (pour pouvoir re-tarer ou annuler à tout moment).
                offset = offsets_pression.get(adresse)
                if offset is not None and "pression" in mesures:
                    p = dict(mesures["pression"])
                    p["valeur"] = round(p["valeur"] - offset, 3)
                    mesures["pression"] = p
                return {"nom": nom, "adresse": adresse,
                        "famille": fiche.get("famille", "") if fiche else "",
                        "etat": fiche["etat"] if fiche else etat_defaut,
                        "trames": fiche["trames"] if fiche else 0,
                        "erreurs": fiche.get("erreurs", 0) if fiche else 0,
                        "mesures": mesures,
                        "tare_pression": offset is not None}
            fusion = []
            adresses_scan = set()
            for s in reponse["sondes"]:
                adresses_scan.add(s["adresse"])
                fusion.append(_resume(s["adresse"], s["nom"],
                                      sondes_validees.get(s["adresse"]), "detectee"))
            for adresse, fiche in list(sondes_validees.items()):
                if adresse not in adresses_scan:
                    fusion.append(_resume(adresse, fiche["nom"], fiche, "detectee"))
            reponse["sondes"] = fusion
            reponse["conseil"] = (
                "Le Bluetooth du PC tient environ 7 sondes à la fois. "
                "Avec un dongle USB : 10 à 12.")
            self._json(reponse)

        elif chemin.path == "/api/mesures":
            # UNE seule source alimente le cycle : celle du mode actif. Chaque
            # valeur porte sa provenance et sa fraîcheur, jamais de mélange.
            mesures = []
            for m in source_active().lire():
                d = asdict(m)
                if m.source == "reel":
                    d["qualite"] = SourceBleReelle.qualite(m)
                else:
                    d["qualite"] = "ok"
                mesures.append(d)
            self._json({
                "mode": mode_actif,
                "mesures": mesures,
                "horodatage": time.time(),
            })

        elif chemin.path == "/api/etat":
            etat = asdict(source_active().etat())
            etat["mode"] = mode_actif
            # Le fluide et les défauts n'ont de sens que côté simulation.
            etat["fluide"] = source_sim.fluide
            etat["defauts"] = source_sim.defauts() if mode_actif == "SIMULATION" else []
            self._json(etat)

        elif chemin.path == "/api/mode":
            # Lecture seule ; le changement se fait en POST.
            self._json({"mode": mode_actif})

        elif chemin.path in self.ROUTES_ACTION:
            self._erreur(405, "Cette action se demande en POST, pas en GET.")

        elif chemin.path == "/":
            self.path = "/index.html"
            super().do_GET()

        else:
            super().do_GET()

    def do_POST(self):
        global mode_actif
        if not self._hote_local():
            self._erreur(403, "Requête refusée : hôte non local.")
            return
        if not self._origine_locale():
            self._erreur(403, "Requête refusée : origine non locale.")
            return
        chemin = urlparse(self.path)
        if chemin.path not in self.ROUTES_ACTION:
            self._erreur(404, "Action inconnue.")
            return

        # Corps JSON borné. Un corps vide vaut {} (actions sans paramètre).
        try:
            longueur = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            longueur = -1
        if not 0 <= longueur <= TAILLE_MAX_CORPS:
            self._erreur(413, "Corps de requête refusé.")
            return
        try:
            corps = json.loads(self.rfile.read(longueur) or b"{}")
            if not isinstance(corps, dict):
                raise ValueError("objet attendu")
        except (ValueError, UnicodeDecodeError):
            self._erreur(400, "Corps JSON invalide.")
            return

        if chemin.path == "/api/mode":
            valeur = corps.get("valeur")
            if valeur not in MODES:
                self._erreur(400, "Mode inconnu (SIMULATION ou REEL).")
                return
            mode_actif = valeur
            journal.info("mode actif : %s", mode_actif)
            self._json({"mode": mode_actif})

        elif chemin.path == "/api/valider":
            adresse = corps.get("adresse")
            if not adresse_valide(adresse):
                self._erreur(400, "Adresse Bluetooth invalide.")
                return
            nom = assainir_nom(corps.get("nom"))
            self._json({"ok": valider_sonde(adresse, nom)})

        elif chemin.path == "/api/devalider":
            adresse = corps.get("adresse")
            if not adresse_valide(adresse):
                self._erreur(400, "Adresse Bluetooth invalide.")
                return
            self._json({"ok": retirer_sonde(adresse)})

        elif chemin.path == "/api/tare":
            # Mise à zéro d'un manomètre : on mémorise sa pression brute actuelle
            # (sonde à l'air libre) comme offset à retrancher ensuite.
            adresse = corps.get("adresse")
            if not adresse_valide(adresse):
                self._erreur(400, "Adresse Bluetooth invalide.")
                return
            fiche = sondes_validees.get(adresse)
            if fiche and "pression" in fiche.get("mesures", {}):
                offsets_pression[adresse] = fiche["mesures"]["pression"]["valeur"]
                _sauver_offsets()
                self._json({"ok": True, "offset": round(offsets_pression[adresse], 3)})
            else:
                self._json({"ok": False, "detail": "Aucune pression lue sur cette sonde."})

        elif chemin.path == "/api/tare_annuler":
            adresse = corps.get("adresse")
            if not adresse_valide(adresse):
                self._erreur(400, "Adresse Bluetooth invalide.")
                return
            offsets_pression.pop(adresse, None)
            _sauver_offsets()
            self._json({"ok": True})

        elif chemin.path == "/api/defaut":
            # Les défauts ne touchent QUE la simulation : ils ne peuvent pas
            # altérer une mesure réelle (source distincte).
            if mode_actif != "SIMULATION":
                self._json({"ok": False, "detail": "Les défauts ne s'appliquent qu'en mode simulation."})
                return
            cle = corps.get("cle")
            if not cle_valide(cle):
                self._erreur(400, "Clé de défaut invalide.")
                return
            try:
                self._json({"cle": cle, "actif": source_sim.basculer_defaut(cle)})
            except KeyError:
                self._erreur(404, "Défaut inconnu.")

        elif chemin.path == "/api/sonde":
            serie = corps.get("serie")
            if not serie_valide(serie):
                self._erreur(400, "Série de sonde invalide.")
                return
            self._json({"serie": serie, "connectee": source_sim.basculer_sonde(serie)})

        elif chemin.path == "/api/fluide":
            cle = corps.get("cle")
            if not cle_valide(cle):
                self._erreur(400, "Clé de fluide invalide.")
                return
            try:
                source_sim.changer_fluide(cle)
                self._json({"fluide": cle})
            except KeyError:
                self._erreur(404, "Fluide inconnu.")

        elif chemin.path == "/api/reinitialiser":
            source_sim.remettre_a_zero()
            self._json({"ok": True})

        elif chemin.path == "/api/journaux/purger":
            self._json({"ok": True, "supprimes": purger_journaux(tout=True)})

        elif chemin.path == "/api/arreter":
            # Arrêt propre demandé depuis la page. La réponse part d'abord,
            # puis le serveur s'éteint depuis un autre thread (shutdown ne
            # peut pas être appelé depuis le thread qui sert la requête).
            self._json({"ok": True, "detail": "Le banc s'arrête."})
            journal.info("arrêt demandé par l'interface")
            if _serveur_http is not None:
                threading.Thread(target=_serveur_http.shutdown, daemon=True).start()

    def _json(self, donnees, code=200):
        corps = json.dumps(donnees, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(corps)

    def _erreur(self, code, detail):
        journal.info("HTTP %d sur %s : %s", code, self.path, detail)
        self._json({"ok": False, "detail": detail}, code=code)

    def log_message(self, format, *args):
        pass


def ouvrir_navigateur(url: str):
    candidats = [
        r"C:\Program Files\Mozilla Firefox\firefox.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    ]
    for chemin in candidats:
        if Path(chemin).exists():
            subprocess.Popen([chemin, url], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return
    webbrowser.open(url)


def _arret_propre(serveur):
    """Éteint tout dans l'ordre : sources, sondes, boucle BLE, serveur.
    Aucun thread non-daemon ne survit : le processus se termine vraiment."""
    source_sim.arreter()
    sondes_validees.clear()          # les boucles de vie sortent d'elles-mêmes
    if _boucle_asyncio is not None:
        _boucle_asyncio.call_soon_threadsafe(lambda: None)  # réveille la boucle
    serveur.server_close()
    journal.info("arrêt propre terminé")


def main():
    global _serveur_http
    parseur = argparse.ArgumentParser(description="inerWeb AquiBlue — Acquisition de données Bluetooth")
    parseur.add_argument("--port", type=int, default=PORT_DEFAUT)
    parseur.add_argument("--sans-navigateur", action="store_true")
    args = parseur.parse_args()

    _preparer_journal_technique()
    journal.info("démarrage, port %d", args.port)
    purger_journaux()                # rotation : garde les plus récents
    _charger_offsets()
    source_sim.demarrer()   # la source réelle est pilotée par le thread BLE
    threading.Thread(target=_boucle_scan_bluetooth, daemon=True).start()
    url = f"http://127.0.0.1:{args.port}/"

    print()
    print("  inerWeb AquiBlue — Acquisition de données Bluetooth")
    print("  Outil indépendant, non affilié à un fabricant d'instruments.")
    print()
    print(f"  Mode       : {mode_actif} (simulation par défaut)")
    print(f"  Adresse    : {url}")
    print(f"  Données    : {DOSSIER_DONNEES}")
    print("  Ctrl+C pour arrêter (ou bouton « Éteindre » de la page)")
    print()

    if not args.sans_navigateur:
        threading.Timer(1.2, ouvrir_navigateur, args=(url,)).start()

    # ThreadingHTTPServer : les navigateurs ouvrent plusieurs connexions
    # persistantes ; un serveur monothread se retrouve bloqué par la première.
    serveur = ThreadingHTTPServer(("127.0.0.1", args.port), Pont)
    _serveur_http = serveur
    try:
        serveur.serve_forever()      # sort sur Ctrl+C ou POST /api/arreter
    except KeyboardInterrupt:
        pass
    _arret_propre(serveur)
    print("\n  Arrêt.")


if __name__ == "__main__":
    main()
